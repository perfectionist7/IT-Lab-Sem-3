#include <LPC17xx.h>
#include<stdlib.h>
unsigned int flag1,temp1,temp2,i,j,key,flag,row,col,x;
unsigned char k;

void port_write(){
	
	LPC_GPIO0->FIOPIN = temp2<<23;
	
	if(flag1==0)
	{
		LPC_GPIO0->FIOCLR=1<<27;
	}
	else
	{
		LPC_GPIO0->FIOSET=1<<27;
	}
	
	LPC_GPIO0->FIOSET=1<<28;
	
	for(j=0;j<50;j++);
	
	LPC_GPIO0->FIOCLR=1<<28;
	
	for(j=0;j<10000;j++);
}

void lcd_write(){
	
	temp2=(temp1>>4)&0xF;
	
	port_write();
	
	temp2 = temp1& 0xF;
	
	port_write();
}
void scan_col()
{
	x=(LPC_GPIO1->FIOPIN>>23 & 0xF);
	if(x!=0)
	{
		flag=0x01;
		switch(x)
		{
			case 1: col=0; break;// 0001 or 0010 or 0100 or 1000
			case 2: col=1; break;
			case 4: col=2; break;
			case 8: col=3; break;
		}
	}
}
void display()
{
	flag1 = 1;
	k = key;//k is char
	if(key>9)
	k=k+0x37;
	else
	k = k + 0x30;
	temp1 = k;
	lcd_write();
	//for (i = 0; i < 100000; i++);
	
	flag1 = 0;
	temp1 = 0x01;
	lcd_write();
	flag1 = 1;
}
int main(void)
{
	int command[] = {3,3,3,2,2,0x01,0x06,0x0C,0x80};
	SystemInit();
	SystemCoreClockUpdate();
	
	LPC_PINCON->PINSEL1 &=0xFC003FFF; //LCD P0.23 TO P0.26 AND P0.27 AND P0.28 made GPIO
  LPC_PINCON->PINSEL3 &=0xFFC03FFF;//KEYBOARD COLS P1.23 to P1.26 MADE GPIO 
	LPC_PINCON->PINSEL4 &=0xF00FFFFF;//KEYBOARD ROWS P2.10 tO P2.13 MADE GPIO
	
	LPC_GPIO0->FIODIR |=0XF<23|1<<27|1<<28;//SET LCD 
	LPC_GPIO2->FIODIR |=0x00003C00;////made output P2.10 to P2.13 (rows)
  LPC_GPIO1->FIODIR &= 0xF87FFFFF; //made input P1.23 to P1.26 (cols)
	flag1=0;
	for( i=0;i<9;i++)
  { 
   temp1 = command[i]; 
	 lcd_write();
  }
	flag1=1;
		while(1)
{
    for(row=0;row<4;row++)
    {
	   display();// will disp even if key not pressed
		 LPC_GPIO2->FIOPIN=1<<(row+10);//row starts from 2.10 hence +10
		 flag=0x00;;
		 for(j=0;j<100;j++);
     scan_col();
		 if(flag==0x01)
		 {
			 key=4*row+col;
			 //display();
			 break;
		 }
	 }
 }
 }
	
	