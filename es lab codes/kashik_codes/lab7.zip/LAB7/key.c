#include <LPC17xx.h>
void scan(void);
unsigned int col,row,var,flag,key,i,x,count=0,flag2;
unsigned int dig_count = 0;
unsigned int digit_value[4] = {0, 0, 0, 0};
unsigned int select_segment[4] = {3 << 23, 2 << 23, 1 << 23, 0 << 23};
unsigned char seven_seg[16] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x67, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71};
void delay()
{
	for (i = 0; i < 500; i++);
	
}
void display()
{
	delay();
	LPC_GPIO1->FIOPIN = select_segment[dig_count];
	LPC_GPIO0->FIOPIN = seven_seg[digit_value[dig_count]] << 4;
	for (i = 0; i < 500; i++);
	LPC_GPIO0->FIOCLR = 0x00000FF0;
		dig_count++;
	if (dig_count == 0x04)
		{
			dig_count = 0x00;
		}
}
void scan_col()
{
	x=(LPC_GPIO1->FIOPIN& 0xF<<23);
	if(x!=0)
	{
		flag=0x01;
		switch(x)
		{
			case 1: col=0; break;
			case 2: col=1; break;
			case 3: col=2; break;
			case 4: col=3; break;
		}
	}
}
	
int main(void)
{
SystemInit();
SystemCoreClockUpdate();

LPC_PINCON->PINSEL0 &= 0x3F0000FF;
LPC_PINCON->PINSEL1 &= 0xFFFFFFC0;
LPC_PINCON->PINSEL3 &= 0xFFC03FFF; //P1.23 to P1.26 MADE GPIO
LPC_PINCON->PINSEL4 &= 0xF00FFFFF; //P2.10 t P2.13 made GPIO

LPC_GPIO0->FIODIR |= 0xF<<15|0xFF<<4;
LPC_GPIO2->FIODIR |= 0x00003C00; //made output P2.10 to P2.13 (rows)
LPC_GPIO1->FIODIR &= 0xF87FFFFF; //made input P1.23 to P1.26 (cols)

	while(1)
{
    for(row=0;row<4;row++)
    {
	   display();// will disp even if key not pressed
		 LPC_GPIO2->FIOPIN=1<<(row+10);//row starts from 2.10 hence +10
		 flag=0;
     scan_col();
		 if(flag==0x01)
		 {
			 key=4*row+col;
			 digit_value[0]=key;
			 break;
		 }
	 }
 }
 }