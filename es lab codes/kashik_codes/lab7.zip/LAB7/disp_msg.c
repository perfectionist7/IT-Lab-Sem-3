#include <LPC17xx.h>
int temp1,temp2, flag1, i;
void port_write()
{
  int j;
  LPC_GPIO0->FIOPIN = temp2 << 23;
  if (flag1 == 0)
	{
    LPC_GPIO0->FIOCLR = 1 << 27;
	}
  else
	{
    LPC_GPIO0->FIOSET = 1 << 27;
	}
  LPC_GPIO0->FIOSET = 1 << 28;
  for (j = 0; j < 50; j++);
  LPC_GPIO0->FIOCLR = 1 << 28;
  for (j = 0; j < 10000; j++);
}
void lcd_write()
{
  temp2 = (temp1 >> 4) & 0xF;
  port_write();
  temp2 = temp1 & 0xF;
  port_write();
}

int main()
{
  int command[] = {3, 3, 3, 2, 0x28, 0x01, 0x06, 0x0C, 0x80};//if not working remove 8 from 0x28
  char message[] = "Jai Shree Ram";
  SystemInit();
  SystemCoreClockUpdate();
  LPC_PINCON->PINSEL1 = 0;//=0xC003FFF;
  LPC_GPIO0->FIODIR = 0XF << 23 | 1 << 27 | 1 << 28;//0x3F<<23;
  flag1 = 0;//0 means cmd mode
  for (i = 0; i < 9; i++)
	{
		temp1 = command[i];
		lcd_write();
	}
 flag1 = 1;
 i = 0;
 while (message[i] != '\0')
	{
    temp1 = message[i];
    lcd_write();
    i++;
		for (i = 0; i < 500000; i++);
		flag1 = 0;
		temp1 = 0x01;
		lcd_write();
		flag1 = 1;
	}
 
}