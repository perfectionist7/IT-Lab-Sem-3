#include<LPC17xx.h>
	unsigned char seven_seg[10]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x67};
  unsigned int x=0;
int main(void)
{
	  SystemInit();
    SystemCoreClockUpdate();
    LPC_PINCON->PINSEL0&=0xFF0000FF;
	  LPC_GPIO0->FIODIR|=0X00000FF0;
	  while(1)
		{
			for(i=0;i<10;i++)
			{
				LPC_GPIO0->FIODIR=seven_seg[i]<<4;
				delay();
			}
		}
	}
	void  delay(void)
 {
   for(j=0;j<10000;j++);
 }
 
	
			